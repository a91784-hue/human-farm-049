import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../dist/vendor/three.module.js';
import {interactionBlocked,findInteraction} from '../dist/interaction-system.js';

const eye=new THREE.Vector3(0,1.65,0);
const table={id:'table',minX:-1,maxX:1,minY:0,maxY:.85,minZ:-2.5,maxZ:-1.5};
const glass={id:'observation_glass',minX:-2,maxX:2,minY:0,maxY:3,minZ:-1.1,maxZ:-1,glass:true,observerLOS:false};
function camera(){const c=new THREE.PerspectiveCamera(72,16/9,.045,145);c.position.copy(eye);c.lookAt(0,1.65,-2);c.updateMatrixWorld(true);return c;}
function target(id,x=0,y=1.65,z=-2,size=.2){
 const mesh=new THREE.Mesh(new THREE.BoxGeometry(size,size,size),new THREE.MeshBasicMaterial());
 mesh.position.set(x,y,z);mesh.updateMatrixWorld(true);
 return {id,mesh,position:mesh.position.clone(),range:3};
}

test('tabletop can be reached over furniture while its solid body blocks a lower target',()=>{
 assert.equal(interactionBlocked(eye,new THREE.Vector3(0,.9,-2),[table],{},'room_record'),false);
 assert.equal(interactionBlocked(eye,new THREE.Vector3(0,.3,-2),[table],{},'button'),true);
 const item=target('room_record',0,.9,-2,.03),c=camera();c.lookAt(item.position);c.updateMatrixWorld(true);
 assert.equal(findInteraction(c,[item],[table],{})?.id,'room_record','same physical reticle helper selects the paper above the tabletop');
});

test('glass allows intended conversation and observation but blocks manipulation',()=>{
 const end=new THREE.Vector3(0,1.4,-2);
 for(const id of ['dahye','lab_window','maze_cctv','control_cctv'])
  assert.equal(interactionBlocked(eye,end,[glass],{},id),false,id);
 for(const id of ['shutter_lever','phone','food'])
  assert.equal(interactionBlocked(eye,end,[glass],{},id),true,id);
 const wall={...glass,id:'wall',glass:false};
 assert.equal(interactionBlocked(eye,end,[glass,wall],{},'dahye'),true,'conversation exemption never bypasses a solid wall');
});

test('reticle rejects an off-center object even when inside the old broad aiming cone',()=>{
 const item=target('service_door',.5,1.65,-2);
 assert.equal(findInteraction(camera(),[item],[],{}),null);
 const c=camera();c.lookAt(item.position);c.updateMatrixWorld(true);
 assert.equal(findInteraction(c,[item],[],{})?.id,item.id);
});

test('small paper tolerance helps precise aiming without restoring broad cone selection',()=>{
 const near=target('room_record',.07,1.65,-2,.01);
 const far=target('room_record',.2,1.65,-2,.01);
 assert.equal(findInteraction(camera(),[near],[],{})?.id,'room_record');
 assert.equal(findInteraction(camera(),[far],[],{}),null);
});

test('a hit mesh behind an occluder is rejected until its own gate is open',()=>{
 const item=target('shutter_lever'),gate={...glass,id:'service_door',glass:false};
 assert.equal(findInteraction(camera(),[item],[gate],{}),null);
 assert.equal(findInteraction(camera(),[item],[gate],{room_door:true}),null);
 assert.equal(findInteraction(camera(),[item],[gate],{service_door:true})?.id,'shutter_lever');
 assert.equal(findInteraction(camera(),[item],[glass],{}),null,'visible control cannot be operated through glass');
 const person=target('dahye');assert.equal(findInteraction(camera(),[person],[glass],{})?.id,'dahye');
});

test('reticle selects nearest hit and respects physical reach and disabled targets',()=>{
 const near=target('chair',0,1.65,-1.5),far=target('service_door',0,1.65,-2.5);
 assert.equal(findInteraction(camera(),[far,near],[],{})?.id,'chair');
 near.disabled=true;assert.equal(findInteraction(camera(),[near,far],[],{})?.id,'service_door');
 far.range=2;assert.equal(findInteraction(camera(),[near,far],[],{}),null);
});
