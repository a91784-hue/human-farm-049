import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createState, interact, tick, enterChapter, documents, objective,
  restoreState, MAZE_SEQUENCE, behaviorProfile, OBSERVATION_SECONDS
} from '../dist/story.js';

function advance(s, seconds, ctx = {}) {
  let left=seconds;
  const effects=[];
  while(left>1e-8){const dt=Math.min(.1,left);effects.push(...tick(s,dt,ctx));left-=dt;}
  return effects;
}
function traverse(s,id) {
  const effects=interact(s,id,{routeRequiresCrossing:true});
  return [...effects,...tick(s,.016,{mazeCrossed:id})];
}

function reachLab(first = 'phone') {
  const s = createState();
  if (first) interact(s, first);
  interact(s, 'curtain');
  enterChapter(s, 2);
  return s;
}
function completeLab(s, chair = 'chair', food = 'food') {
  if (chair) interact(s, chair);
  else for (let i = 0; i < 19; i++) tick(s, 1);
  interact(s, food);
  interact(s, 'changed_object');
  interact(s, 'lab_window');
  advance(s,OBSERVATION_SECONDS,{focusId:'lab_window',moving:false});
  interact(s, 'changed_object');
  assert.equal(s.flags.labComplete, true);
}
function reachMaze() {
  const s = reachLab();
  completeLab(s);
  interact(s, 'feed_lab');
  interact(s, 'hatch_lab', {watched:false,feedActive:true});
  enterChapter(s, 3);
  return s;
}
function reachFinal() {
  const s = reachMaze();
  for (const door of MAZE_SEQUENCE) traverse(s, door);
  enterChapter(s, 4);
  enterChapter(s, 5);
  return s;
}

test('the first inspected object is preserved and reflected later', () => {
  for (const first of ['phone','room_record','room_door']) {
    const s=createState();
    interact(s,first);
    for (const other of ['phone','room_record','room_door']) interact(s,other);
    assert.equal(s.choices.firstObject,first);
    interact(s,'curtain');
    const effects=enterChapter(s,2);
    assert(effects.some(e=>e.id===`first_${first}`));
    const doc=documents(s).find(d=>d.id==='behavior');
    assert(doc.text.includes({phone:'휴대전화',room_record:'책상 위 기록',room_door:'현관문'}[first]));
  }
});

test('curtain opened first records no invented inspection', () => {
  const s=reachLab(null);
  interact(s,'phone');
  assert.equal(s.choices.firstObject,null);
  assert(documents(s).find(d=>d.id==='behavior').text.includes('다른 물체를 조사하지 않고 커튼을 엶'));
});

test('chapter transitions require preceding puzzle completion', () => {
  const s=createState();
  for (const next of [2,3,4,5,6]) enterChapter(s,next);
  assert.equal(s.chapter,1);
  interact(s,'curtain'); enterChapter(s,2);
  assert.equal(s.chapter,2);
  enterChapter(s,3); assert.equal(s.chapter,2);
});

test('accept, refuse and no response are different actual chair records', () => {
  for (const [action,result] of [['chair','sat'],['refuse_chair','refused'],[null,'inactive']]) {
    const s=reachLab(); completeLab(s,action);
    assert.equal(s.choices.chair,result);
    interact(s,result==='sat'?'refuse_chair':'chair');
    assert.equal(s.choices.chair,result,'later button does not rewrite recorded experiment');
  }
});

test('pause does not count as no response', () => {
  const s=reachLab();
  for(let i=0;i<100;i++) tick(s,1,{paused:true});
  assert.equal(s.choices.chair,null);
  for(let i=0;i<17;i++) tick(s,1);
  assert.equal(s.choices.chair,null);
  tick(s,1);
  assert.equal(s.choices.chair,'inactive');
});

test('food journal distinguishes looking from drinking and preserves sequence', () => {
  const s=reachLab();
  interact(s,'food');
  let text=documents(s).find(d=>d.id==='behavior').text;
  assert(text.includes('식판을 살펴봄'));
  assert(!text.includes('물을 마심'));
  interact(s,'refuse_food'); interact(s,'water'); interact(s,'water');
  assert.deepEqual(s.choices.foodActions,['inspected','refused','drank']);
  text=documents(s).find(d=>d.id==='behavior').text;
  assert(text.includes('식판을 살펴봄 → 급식을 거부함 → 물을 마심'));
});

test('a spatial change cannot be detected before it occurs', () => {
  const s=reachLab();
  interact(s,'changed_object');
  assert.equal(s.flags.objectRemembered,true);
  assert(!s.choices.spaceChecks.includes('changed_object'));
  interact(s,'lab_window');
  assert(!s.flags.objectMoved,'pressing E on window alone is not observing');
  advance(s,OBSERVATION_SECONDS,{focusId:'lab_window',moving:false});
  assert.equal(s.flags.objectMoved,true);
  interact(s,'changed_object');
  assert(s.choices.spaceChecks.includes('changed_object'));
});

test('lab escape needs completed tests and distracted observation', () => {
  const s=reachLab();
  interact(s,'feed_lab');
  interact(s,'hatch_lab',{feedActive:true});
  assert(!s.flags.labEscaped);
  completeLab(s);
  for(let i=0;i<11;i++) tick(s,1);
  interact(s,'hatch_lab',{watched:true});
  assert(!s.flags.labEscaped);
  interact(s,'feed_lab');
  interact(s,'hatch_lab',{feedActive:true});
  assert.equal(s.flags.labEscaped,true);
  assert.equal(s.openDoors.hatch_lab,true);
});

test('maze wrong routes reset position but retain completed stages', () => {
  const s=reachMaze();
  const bad=traverse(s,'maze_right');
  assert.equal(s.mazeStep,0);
  assert(bad.some(e=>e.type==='teleport'&&e.z===38));
  traverse(s,'maze_left'); assert.equal(s.mazeStep,1);
  traverse(s,'maze_left'); assert.equal(s.mazeStep,1);
  traverse(s,'maze_right'); assert.equal(s.mazeStep,2);
  traverse(s,'maze_center');
  assert.equal(s.flags.mazeSolved,true);
  assert.equal(s.openDoors.maze_exit,true);
  assert.equal(s.mazeLoops,5);
  assert.equal(s.choices.mazeHistory.filter(v=>v.correct).length,3);
});

test('both final choices are reversible and neither is an ending', () => {
  const s=reachFinal();
  for (const id of ['choice_a','choice_b','choice_a']) {
    const effects=interact(s,id);
    assert(!effects.some(e=>e.type==='ending'));
    assert(!s.flags.escaped);
  }
  assert.equal(s.openDoors.choice_a_door,true);
  assert.equal(s.openDoors.choice_b_door,true);
  assert.deepEqual(s.choices.finalChoices,['A','B']);
  interact(s,'blueprint'); interact(s,'final_record'); interact(s,'feed_final'); interact(s,'shield',{feedActive:true});
  interact(s,'service_door',{feedActive:true});
  assert.equal(s.flags.serviceOpen,true);
});

test('all maintenance-route prerequisites are required', () => {
  const s=reachFinal();
  interact(s,'service_door',{feedActive:true,hidden:true}); assert(!s.flags.serviceOpen);
  interact(s,'blueprint');
  interact(s,'service_door',{feedActive:true,hidden:true}); assert(!s.flags.serviceOpen);
  interact(s,'final_record');
  interact(s,'service_door',{feedActive:true,hidden:true}); assert(!s.flags.serviceOpen);
  interact(s,'shield',{watched:true}); assert(!s.flags.shieldActive);
  interact(s,'feed_final'); interact(s,'shield',{feedActive:true,watched:false});
  for(let i=0;i<13;i++) tick(s,1);
  interact(s,'service_door',{watched:true}); assert(!s.flags.serviceOpen);
  interact(s,'service_door',{hidden:true}); assert.equal(s.flags.serviceOpen,true);
});

test('opening the exit gate cannot replace walking outside', () => {
  const s=reachFinal();
  interact(s,'blueprint'); interact(s,'final_record'); interact(s,'feed_final'); interact(s,'shield',{feedActive:true});
  interact(s,'service_door',{feedActive:true}); enterChapter(s,6);
  interact(s,'exit_gate'); assert(!s.flags.gateOpen);
  const shutters=interact(s,'shutter_lever');
  assert(shutters.some(e=>e.type==='shutters'));
  const gate=interact(s,'exit_gate');
  assert(!gate.some(e=>e.type==='ending'));
  assert(!s.flags.escaped);
  const outside=interact(s,'outside');
  assert.equal(s.flags.escaped,true);
  assert(outside.some(e=>e.type==='ending'));
  assert.deepEqual(interact(s,'outside'),[],'ending cannot trigger twice');
});

test('restored checkpoint preserves choices and world state, clears transient exposure', () => {
  const s=reachMaze();
  traverse(s,'maze_left');
  s.exposure=0.8;
  const copy=restoreState(JSON.stringify(s));
  assert.equal(copy.chapter,3);
  assert.equal(copy.mazeStep,1);
  assert.equal(copy.openDoors.room_door,true);
  assert.equal(copy.openDoors.hatch_lab,true);
  assert.equal(copy.choices.firstObject,'phone');
  assert.equal(copy.choices.chair,'sat');
  assert.equal(copy.exposure,0);
  assert.equal(copy.feedUntil,0);
  traverse(copy,'maze_right'); traverse(copy,'maze_center');
  enterChapter(copy,4);
  assert.equal(copy.chapter,4);
});

test('malformed or incompatible save safely creates a new state', () => {
  for(const raw of ['{bad',null,[],{version:99}]) assert.deepEqual(restoreState(raw),createState());
  const repaired=restoreState({version:1,chapter:99,elapsed:-3,choices:{foodActions:['fake','drank'],firstObject:'fake'},flags:{constructor:'bad',curtainOpen:true}});
  assert.equal(repaired.chapter,6);
  assert.equal(repaired.elapsed,0);
  assert.equal(repaired.choices.firstObject,null);
  assert.deepEqual(repaired.choices.foodActions,['drank']);
  assert.equal(repaired.openDoors.room_door,true);
});

test('every chapter offers a concrete current objective', () => {
  const s=createState();
  for(let n=1;n<=6;n++) {
    s.chapter=n;
    assert.equal(typeof objective(s),'string');
    assert(objective(s).length>4);
  }
});

test('spatial experiment requires a real baseline and cumulative stationary gaze',()=>{
  const s=reachLab();
  interact(s,'lab_window');
  advance(s,4,{focusId:'lab_window',moving:false});
  assert(!s.flags.objectMoved,'window cannot move an unmemorized object');
  interact(s,'changed_object'); interact(s,'lab_window');
  advance(s,4,{focusId:'phone',moving:false});
  assert.equal(s.labObservation.progress,0);
  advance(s,4,{focusId:'lab_window',moving:true});
  assert.equal(s.labObservation.progress,0);
  advance(s,1,{focusId:'lab_window',moving:false});
  assert(s.labObservation.progress>.99&&s.labObservation.progress<1.01);
  advance(s,5,{focusId:'lab_window',paused:true});
  assert(s.labObservation.progress<1.01,'reading/pause does not complete observation');
  for(let i=0;i<5;i++)interact(s,'lab_window');
  assert(s.labObservation.progress<1.01,'E repetitions cannot fabricate observation');
  advance(s,1.3,{focusId:'lab_window',moving:false});
  assert.equal(s.flags.objectMoved,true);
  assert(!s.choices.spaceChecks.includes('changed_object'),'looking at window is not comparing the moved object');
  interact(s,'changed_object');
  assert(s.choices.spaceChecks.includes('changed_object'));
});

test('partial observation progress survives checkpoint and still needs the remainder',()=>{
  const s=reachLab();interact(s,'changed_object');interact(s,'lab_window');
  advance(s,1.5,{focusId:'lab_window',moving:false});
  const copy=restoreState(JSON.stringify(s));
  assert.equal(copy.labObservation.phase,'watching');
  assert(!copy.flags.objectMoved);
  advance(copy,.3,{focusId:'lab_window',moving:false});
  assert(!copy.flags.objectMoved);
  advance(copy,.5,{focusId:'lab_window',moving:false});
  assert.equal(copy.flags.objectMoved,true);
});

test('legacy tick callers retain timed compatibility without an instant E completion',()=>{
  const s=reachLab();interact(s,'changed_object');interact(s,'lab_window');
  assert(!s.flags.objectMoved);
  advance(s,2.3);
  assert.equal(s.flags.objectMoved,true);
});

test('behavior model distinguishes explicit refusal from withheld response',()=>{
  const refused=reachLab();interact(refused,'refuse_chair');
  const withheld=reachLab();advance(withheld,18.1);
  assert.equal(behaviorProfile(refused).obedience,-1);
  assert.equal(behaviorProfile(withheld).obedience,0);
  assert.notEqual(behaviorProfile(refused).response,behaviorProfile(withheld).response);
  assert.equal(withheld.choices.chairLatency,18);
  assert(!withheld.events.some(e=>e.id==='chair'&&e.detail==='refused'));
});

test('profile does not rewrite food order or farm curiosity through repeated E',()=>{
  const a=reachLab();interact(a,'water');interact(a,'food');
  const b=reachLab();interact(b,'food');interact(b,'water');
  assert.notEqual(behaviorProfile(a).feeding,behaviorProfile(b).feeding);
  interact(a,'room_record');
  const count=behaviorProfile(a).curiosity;
  for(let i=0;i<20;i++)interact(a,'room_record');
  assert.equal(behaviorProfile(a).curiosity,count);
});

test('actual behavior changes later observations without changing path solvability',()=>{
  const a=reachLab();completeLab(a,'chair','water');
  const b=reachLab();completeLab(b,'refuse_chair','refuse_food');
  for(const s of [a,b]){interact(s,'feed_lab');interact(s,'hatch_lab',{feedActive:true});}
  const ea=enterChapter(a,3),eb=enterChapter(b,3);
  assert.notEqual(ea.find(e=>e.id==='maze_profile').text,eb.find(e=>e.id==='maze_profile').text);
  assert.notEqual(behaviorProfile(a).label,behaviorProfile(b).label);
  for(const s of [a,b])for(const id of MAZE_SEQUENCE)traverse(s,id);
  assert(a.flags.mazeSolved&&b.flags.mazeSolved);
});

test('feed cannot be extended by pressing E and has a fair unlimited floor',()=>{
  const s=reachLab();
  const durations=[];
  for(let i=0;i<6;i++){
    const start=interact(s,'feed_lab').find(e=>e.type==='feed');
    assert(start);
    durations.push(start.duration);
    const deadline=s.feedUntil;
    advance(s,1);
    const duplicate=interact(s,'feed_lab');
    assert(!duplicate.some(e=>e.type==='feed'));
    assert.equal(s.feedUntil,deadline);
    advance(s,start.duration-.9);
    const cooldown=interact(s,'feed_lab');
    assert(!cooldown.some(e=>e.type==='feed'));
    advance(s,2);
  }
  assert.deepEqual(durations,[10,9,8,8,8,8]);
  assert.equal(s.feedCycles.lab,6);
});

test('final feeding resets between zones and does not shrink below ten seconds',()=>{
  const s=reachFinal();
  const durations=[];
  for(let i=0;i<4;i++){
    const e=interact(s,'feed_final').find(e=>e.type==='feed');
    assert(e);durations.push(e.duration);advance(s,e.duration+2.1);
  }
  assert.deepEqual(durations,[12,11,10,10]);
  const copy=restoreState(s);
  assert.equal(copy.feedCycles.final,4);
  assert.equal(copy.feedUntil,0);
  assert.equal(copy.feedReadyAt,0);
  assert.equal(interact(copy,'feed_final').find(e=>e.type==='feed').duration,10);
});

test('opening a maze door is not a choice until the player crosses it',()=>{
  const s=reachMaze();
  const e=interact(s,'maze_left',{routeRequiresCrossing:true});
  assert(e.some(e=>e.type==='maze-route'));
  assert.equal(s.mazeStep,0);assert.equal(s.mazeLoops,0);
  assert.equal(s.pendingMazeDoor,'maze_left');
  advance(s,5,{mazeCrossed:'maze_right'});
  assert.equal(s.mazeStep,0,'crossing a different door cannot resolve the pending one');
  interact(s,'maze_right',{routeRequiresCrossing:true});
  assert(!s.openDoors.maze_left);assert(s.openDoors.maze_right);
  tick(s,.1,{mazeCrossed:'maze_right'});
  assert.equal(s.mazeLoops,1);assert.equal(s.mazeStep,0);
  tick(s,.1,{mazeCrossed:'maze_right'});
  assert.equal(s.mazeLoops,1,'one crossing is never counted twice');
});

test('pending maze door restores open and solved maze restores both passage gates',()=>{
  const s=reachMaze();interact(s,'maze_left',{routeRequiresCrossing:true});
  const pending=restoreState(JSON.stringify(s));
  assert.equal(pending.pendingMazeDoor,'maze_left');assert(pending.openDoors.maze_left);
  tick(pending,.1,{mazeCrossed:'maze_left'});
  traverse(pending,'maze_right');traverse(pending,'maze_center');
  const solved=restoreState(JSON.stringify(pending));
  assert.equal(solved.pendingMazeDoor,null);
  assert.equal(solved.openDoors.maze_center,true);
  assert.equal(solved.openDoors.maze_exit,true);
  assert.equal(solved.mazeStep,3);
});

test('final button does not reveal an unvisited room or silently complete its observation',()=>{
  const s=reachFinal();
  const e=interact(s,'choice_b');
  assert.deepEqual(s.choices.finalOutcomes,[]);
  assert(!e.some(v=>v.type==='toast'&&v.text.includes('실험실이다')));
  const before=documents(s).find(d=>d.id==='final').text;
  assert(before.includes('아직 안쪽을 직접 확인하지 않음'));
  assert(!before.includes('두 회로 모두 시설 내부'));
  tick(s,.1,{observedChoice:'A'});
  assert.deepEqual(s.choices.finalOutcomes,[],'unopened A cannot be observed');
  tick(s,.1,{observedChoice:'B'});
  assert.deepEqual(s.choices.finalOutcomes,['B']);
  tick(s,.1,{observedChoice:'B'});
  assert.equal(s.events.filter(e=>e.id==='final_outcome_seen').length,1);
  assert(documents(s).find(d=>d.id==='final').text.includes('B: 출구 표지 뒤에 또 다른 실험실'));
});

test('witnessing a false route is an alternate clue to the optional operation record',()=>{
  const s=reachFinal();interact(s,'blueprint');interact(s,'choice_a');
  tick(s,.1,{observedChoice:'A'});
  assert(!s.flags.finalRecordRead);
  interact(s,'feed_final');interact(s,'shield',{feedActive:true});
  interact(s,'service_door',{feedActive:true});
  assert.equal(s.flags.serviceOpen,true);
});

test('the facility prediction stays fixed while the real first choice is retained',()=>{
  const s=reachFinal();
  const prediction=s.choices.predictedFinal;
  interact(s,'dahye');interact(s,'final_record');interact(s,'control_cctv');
  assert.equal(behaviorProfile(s).predictedChoice,prediction);
  interact(s,'choice_a');interact(s,'choice_b');
  assert.equal(s.choices.finalChoices[0],'A');
  assert.equal(behaviorProfile(s).social,'타 개체의 문부터 개방');
  const copy=restoreState(JSON.stringify(s));
  assert.equal(behaviorProfile(copy).predictedChoice,prediction);
  assert.deepEqual(behaviorProfile(copy).evidence,behaviorProfile(s).evidence);
});
