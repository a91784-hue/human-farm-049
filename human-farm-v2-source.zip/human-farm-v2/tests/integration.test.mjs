import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../dist/vendor/three.module.js';
import {buildWorld} from '../dist/world.js';
import {createState,interact,tick,enterChapter,restoreState} from '../dist/story.js';
import {pointBlocked,segmentBlocked,moveWithCollisions} from '../dist/physics.js';
import {findInteraction} from '../dist/interaction-system.js';

// World/physics/story integration, not a rendered browser test. Canvas authors
// material textures only; Three mesh transforms and collisions remain real.
globalThis.document={createElement(){
 const ctx=new Proxy({getImageData(x,y,w,h){return {data:new Uint8ClampedArray(w*h*4)};}},
  {get(t,k){return k in t?t[k]:(()=>{});}});
 return {width:256,height:256,getContext:()=>ctx};
}};

function harness(){
 const scene=new THREE.Scene(),world=buildWorld(scene),state=createState(),p={x:0,z:5};
 const camera=new THREE.PerspectiveCamera(72,16/9,.045,145);
 let distance=0,teleports=0;
 const bp=new THREE.Vector3(),bd=new THREE.Vector3(),v=new THREE.Vector3();
 const item=id=>{const it=world.interactables.find(i=>i.id===id);assert.ok(it,`physical object ${id}`);return it;};
 function apply(effects){for(const e of effects)if(e.type==='teleport'){p.x=e.x;p.z=e.z;teleports++;}}
 function context(extra={}){
  let sees=0,blocked=0;
  if(!state.flags.shuttersClosed)for(const b of world.birds.filter(b=>b.zone===state.chapter)){
   b.head.getWorldPosition(bp);if(Math.hypot(bp.x-p.x,bp.z-p.z)>24)continue;
   b.head.getWorldDirection(bd);bd.y=0;bd.normalize();v.set(p.x-bp.x,0,p.z-bp.z).normalize();
   if(v.dot(bd)<.4)continue;
   if(segmentBlocked(bp.x,bp.z,p.x,p.z,world.colliders,state.openDoors,{observation:true}))blocked++;else sees++;
  }
  let mazeCrossed=null,observedChoice=null;
  if(state.pendingMazeDoor){const door=item(state.pendingMazeDoor);if(p.z>57.45&&Math.abs(p.x-door.position.x)<1.3)mazeCrossed=door.id;}
  if(state.openDoors.choice_a_door&&p.z>114.5&&p.z<117.3&&p.x>-6.3&&p.x<-3.7)observedChoice='A';
  if(state.openDoors.choice_b_door&&p.z>114.5&&p.z<117.3&&p.x>-1.3&&p.x<1.3)observedChoice='B';
  return {watched:sees>0,hidden:!sees&&blocked>0,feedActive:state.feedUntil>state.elapsed,
   moving:false,focusId:null,routeRequiresCrossing:true,mazeCrossed,observedChoice,...extra};
 }
 function boundary(){
  let n=state.chapter;
  if(p.z>=14&&n===1)n=2;else if(p.z>=36&&n===2)n=3;else if(p.z>=66&&n===3)n=4;
  else if(p.z>=98&&n===4)n=5;else if(p.z>=118.2&&n===5)n=6;
  if(n!==state.chapter)apply(enterChapter(state,n));
  if(p.z>=154&&state.chapter===6)apply(interact(state,'outside',context()));
 }
 function frame(dt,extra={}){
  world.update(state.elapsed,dt,{...state,feedActive:state.feedUntil>state.elapsed},p);scene.updateMatrixWorld(true);
  if(extra.focusId)assert.equal(findInteraction(camera,world.interactables,world.colliders,state.openDoors)?.id,extra.focusId,'sustained focus remains an actual reticle hit');
  apply(tick(state,dt,context(extra)));boundary();
 }
 function wait(seconds,extra={}){for(let left=seconds;left>1e-8;left-=.05)frame(Math.min(.05,left),extra);}
 function path(tx,tz,range=.4){
  const step=.5,key=(x,z)=>x+','+z,sx=Math.round(p.x/step),sz=Math.round(p.z/step),q=[[sx,sz]],parent=new Map([[key(sx,sz),null]]);let end;
  for(let i=0;i<q.length&&i<28000;i++){
   const[x,z]=q[i],wx=x*step,wz=z*step;
   if(Math.hypot(wx-tx,wz-tz)<Math.max(.4,range-.5)&&!segmentBlocked(wx,wz,tx,tz,world.colliders,state.openDoors,{observation:true})){end=[x,z];break;}
   for(const[dx,dz]of[[0,1],[1,0],[-1,0],[0,-1]]){
    const nx=x+dx,nz=z+dz,k=key(nx,nz);
    if(nx<-20||nx>32||nz<1||nz>327||parent.has(k)||pointBlocked(nx*step,nz*step,world.colliders,state.openDoors,.27))continue;
    parent.set(k,[x,z]);q.push([nx,nz]);
   }
  }
  assert.ok(end,`physical route to ${tx},${tz}, CH${state.chapter}`);
  const out=[];while(end){out.push({x:end[0]*step,z:end[1]*step});end=parent.get(key(...end));}return out.reverse();
 }
 function walk(tx,tz,range=.4,speed=2.5){
  const initialTeleports=teleports;
  for(const next of path(tx,tz,range)){
   const dx=next.x-p.x,dz=next.z-p.z,length=Math.hypot(dx,dz),steps=Math.max(1,Math.ceil(length/(speed*.05)));
   for(let s=0;s<steps;s++){
    const before={...p};moveWithCollisions(p,dx/steps,dz/steps,world.colliders,state.openDoors);
    distance+=Math.hypot(p.x-before.x,p.z-before.z);frame(length/(speed*steps),{moving:true});
    if(teleports!==initialTeleports)return;
   }
   assert.ok(Math.hypot(p.x-next.x,p.z-next.z)<.05,'route uses actual collision solver');
  }
 }
 function act(id){
  const it=item(id);walk(it.position.x,it.position.z,it.range);wait(.1);
  const d=Math.hypot(p.x-it.position.x,p.z-it.position.z,1.65-it.position.y);
  assert.ok(d<=it.range,`3D interaction range: ${id}`);
  assert.equal(segmentBlocked(p.x,p.z,it.position.x,it.position.z,world.colliders,state.openDoors,{observation:true,skipIds:[id]}),false,`visible interaction ${id}`);
  camera.position.set(p.x,1.65,p.z);camera.lookAt(it.position);camera.updateMatrixWorld(true);
  assert.equal(findInteraction(camera,world.interactables,world.colliders,state.openDoors)?.id,id,`normal reticle selects ${id} from ${p.x},${p.z}`);
  const result=interact(state,id,context());apply(result);wait(.1);return result;
 }
 function chooseMaze(id){
  const beforeStep=state.mazeStep,beforeLoops=state.mazeLoops,door=item(id);act(id);
  assert.equal(state.mazeStep,beforeStep,'E opens the selected route without counting a traversal');
  assert.equal(state.mazeLoops,beforeLoops,'a choice is not recorded until the player crosses');
  wait(.7);walk(door.position.x,58,.4);
  assert.equal(state.mazeLoops,beforeLoops+1,'physical crossing records exactly one traversal');
 }
 function solveLab(){
  act('chair');act('refuse_food');act('changed_object');
  assert.equal(state.flags.objectMoved,undefined,'baseline alone cannot report a changed object');
  act('lab_window');wait(.8,{focusId:'lab_window'});wait(.4,{focusId:null});
  assert.equal(state.flags.objectMoved,undefined,'a brief look cannot complete the observation');
  wait(2.4,{focusId:'lab_window'});assert.equal(state.flags.objectMoved,true);
  act('changed_object');assert.equal(state.flags.labComplete,true);act('feed_lab');act('hatch_lab');
 }
 function toMazeSolved(){
  act('phone');act('curtain');solveLab();chooseMaze('maze_left');chooseMaze('maze_right');chooseMaze('maze_center');
  assert.equal(state.flags.mazeSolved,true);
 }
 function restore(){const savedPosition={...p},restored=restoreState(JSON.parse(JSON.stringify(state)));Object.assign(state,restored);Object.assign(p,savedPosition);wait(.1);}
 wait(.05);
 return {state,p,scene,world,item,act,walk,wait,context,chooseMaze,solveLab,toMazeSolved,restore,get distance(){return distance;}};
}

test('six chapters complete using walking speed, sustained gaze and physical maze crossings',()=>{
 const h=harness();h.act('phone');h.act('room_record');h.act('curtain');h.solveLab();h.act('maze_record');
 h.chooseMaze('maze_right');h.chooseMaze('maze_left');h.chooseMaze('maze_right');h.chooseMaze('maze_center');
 for(const id of['atrium_record','blueprint','dahye','control_cctv','final_record'])h.act(id);
 h.act('choice_a');assert.deepEqual(h.state.choices.finalOutcomes,[],'a switch does not report a room that was not explored');
 h.walk(-5,116);assert.ok(h.state.choices.finalOutcomes.includes('A'));
 h.act('choice_b');h.walk(0,116);assert.ok(h.state.choices.finalOutcomes.includes('B'));
 for(const id of['feed_final','shield','service_door','shutter_lever','exit_gate'])h.act(id);
 assert.equal(h.state.chapter,6);assert.equal(h.state.flags.shuttersClosed,true);
 assert.equal(h.state.flags.escaped,undefined,'opening the gate is not escape');
 h.walk(6,155);assert.equal(h.state.flags.escaped,true);assert.ok(h.distance>150,'actual corridor route traversed');
 assert.equal(h.state.choices.firstObject,'phone');assert.deepEqual(h.state.choices.finalChoices,['A','B']);
});

test('solved maze checkpoint preserves the physical route after reload',()=>{
 const h=harness();h.toMazeSolved();h.restore();h.walk(0,55);h.walk(0,67.5);
 assert.equal(h.state.chapter,4,'both solved selection door and maintenance exit remain passable');
});

test('final screen blocks actual pigeon sight only when deployed',()=>{
 const h=harness();h.state.chapter=5;h.p.x=6;h.p.z=115;h.wait(1);
 assert.equal(h.context().watched,true,'ordinary observers see the service route');
 h.state.flags.shieldActive=true;h.wait(1);
 assert.equal(h.context().watched,false,'screen blocks the gaze');assert.equal(h.context().hidden,true);
});

test('fresh state closes previously opened doors, shutters and curtain',()=>{
 const h=harness();h.world.update(0,5,{flags:{curtainOpen:true,shuttersClosed:true},openDoors:{room_door:true},chapter:1},{x:0,z:5});
 h.world.update(1,5,createState(),{x:0,z:5});
 assert.ok(h.world.doors.room_door.position.y<.001);assert.ok(h.world.curtain.scale.z>.999);
});

test('missing the lab distraction window still permits an ordinary retry',()=>{
 const h=harness();h.act('phone');h.act('curtain');h.solveLab();
 h.state.flags.labEscaped=false;delete h.state.openDoors.hatch_lab;
 h.wait(20);h.act('hatch_lab');assert.equal(h.state.flags.labEscaped,false,'expired signal cannot open an observed lock');
 h.act('feed_lab');h.act('hatch_lab');assert.equal(h.state.flags.labEscaped,true);
 h.walk(0,38);assert.equal(h.state.chapter,3);
});

test('alternative experiment inputs are physically selectable and record their actual order',()=>{
 const h=harness();h.act('room_door');h.act('curtain');
 h.act('refuse_chair');h.act('food');h.act('water');h.act('lab_door');
 assert.equal(h.state.choices.firstObject,'room_door');
 assert.equal(h.state.choices.chair,'refused');
 assert.deepEqual(h.state.choices.foodActions,['inspected','drank']);
 h.act('changed_object');h.act('lab_window');h.wait(2.4,{focusId:'lab_window'});h.act('changed_object');
 h.act('feed_lab');h.act('hatch_lab');h.act('maze_cctv');
 assert.equal(h.state.chapter,3);
 assert.ok(h.state.choices.examined.includes('maze_cctv'));
});
