import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const files=fs.readdirSync('dist').filter(f=>f.endsWith('.js')).map(f=>path.join('dist',f));
for(const file of files){const r=spawnSync(process.execPath,['--check',file],{stdio:'inherit'});if(r.status)process.exit(r.status);}
for(const file of ['dist/index.html','dist/style.css',...files])if(fs.readFileSync(file,'utf8').includes('\ufffd'))throw Error('Invalid replacement character in '+file);
console.log(`Checked ${files.length} application modules and UTF-8 assets.`);
