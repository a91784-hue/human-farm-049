import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('dist'),imports={},seen=new Set();
const pattern=/(\bfrom\s*|\bimport\s*)(['"])(\.{1,2}\/[^'"]+)\2/g;
const name=file=>'hf/'+path.relative(root,file).replaceAll('\\','/');
function visit(file){
 if(seen.has(file))return name(file);
 if(!file.startsWith(root+path.sep))throw new Error('Module outside distribution: '+file);
 seen.add(file);
 const source=fs.readFileSync(file,'utf8').replace(pattern,(all,prefix,quote,relative)=>{
  const dependency=path.resolve(path.dirname(file),relative);
  return `${prefix}${quote}${visit(dependency)}${quote}`;
 });
 imports[name(file)]='data:text/javascript;base64,'+Buffer.from(source).toString('base64');
 return name(file);
}
const entry=visit(path.join(root,'game.js'));
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
html=html.replace('<link rel="stylesheet" href="style.css">',`<style>${fs.readFileSync(path.join(root,'style.css'),'utf8')}</style>`);
const assets=JSON.parse(fs.readFileSync(path.join(root,'assets/asset-manifest.json'),'utf8'));
html=html.replace('<script type="module" src="game.js"></script>',`<script>globalThis.HF_STANDALONE=true;globalThis.HF_ASSETS=${JSON.stringify(assets).replaceAll('<','\\u003c')};</script><script type="importmap">${JSON.stringify({imports})}</script><script type="module">import '${entry}';</script>`);
fs.writeFileSync('human-farm.html',html);
fs.mkdirSync('staging',{recursive:true});fs.writeFileSync('staging/v2.html',html);
console.log(JSON.stringify({file:path.resolve('human-farm.html'),modules:seen.size,bytes:Buffer.byteLength(html)}));
