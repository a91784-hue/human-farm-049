import test from 'node:test';
import assert from 'node:assert/strict';
import {pointBlocked,segmentBlocked,moveWithCollisions} from '../dist/physics.js';

const wall = {minX:2,maxX:3,minZ:-5,maxZ:5};
const door = {id:'hatch_lab',minX:-1,maxX:1,minZ:2,maxZ:2.15};

test('player radius is respected at walls',()=>{
  assert(pointBlocked(1.8,0,[wall],{}));
  assert(!pointBlocked(1.7,0,[wall],{}));
  assert(pointBlocked(2.5,0,[wall],{},0));
});

test('large movement cannot tunnel through thick wall or narrow door',()=>{
  const p={x:0,z:0};
  moveWithCollisions(p,20,0,[wall],{});
  assert(p.x<1.77&&p.x>1.5);
  const q={x:0,z:0};
  moveWithCollisions(q,0,20,[door],{});
  assert(q.z<1.77&&q.z>1.5);
});

test('open door becomes passable, unrelated door flags cannot affect it',()=>{
  const p={x:0,z:0};
  moveWithCollisions(p,0,4,[door],{hatch_lab:true});
  assert(Math.abs(p.z-4)<1e-7);
  const q={x:0,z:0};
  moveWithCollisions(q,0,4,[door],{room_door:true});
  assert(q.z<2);
});

test('diagonal movement slides along the unblocked wall axis',()=>{
  const p={x:1.7,z:0};
  const result=moveWithCollisions(p,3,3,[wall],{});
  assert(p.x<1.77);
  assert(Math.abs(p.z-3)<1e-7);
  assert.equal(result.blockedX,true);
  assert.equal(result.blockedZ,false);
});

test('Object3D-style position mutation does not alter vertical position',()=>{
  const p={position:{x:0,y:1.65,z:0}};
  moveWithCollisions(p,1,1,[],{});
  assert(Math.abs(p.position.x-1)<1e-7);
  assert.equal(p.position.y,1.65);
});

test('exact finite segment sees wall even when extremely narrow',()=>{
  const tiny={minX:1.0001,maxX:1.0002,minZ:-1,maxZ:1};
  assert(segmentBlocked(0,0,3,0,[tiny],{}));
  assert(!segmentBlocked(0,0,.5,0,[tiny],{}));
  assert(!segmentBlocked(0,2,3,2,[tiny],{}));
});

test('ordinary wall blocks observer gaze while observation glass passes it',()=>{
  assert(segmentBlocked(0,0,4,0,[wall],{},{observation:true}));
  assert(!segmentBlocked(0,0,4,0,[{...wall,glass:true}],{},{observation:true}));
  assert(!segmentBlocked(0,0,4,0,[{...wall,observerLOS:false}],{},{observation:true}));
  assert(segmentBlocked(0,0,4,0,[{...wall,glass:true}],{},{}),'glass still blocks physical interaction ray');
});

test('explicit skip ID ignores the target housing but not another wall',()=>{
  const target={...wall,id:'target'};
  assert(!segmentBlocked(0,0,4,0,[target],{},{skipIds:['target']}));
  assert(segmentBlocked(0,0,4,0,[target,{minX:.5,maxX:.6,minZ:-1,maxZ:1}],{},{skipIds:['target']}));
});

test('observer in its wall housing can see out but other walls still block',()=>{
  const housing={minX:-.2,maxX:.2,minZ:-.2,maxZ:.2};
  assert(!segmentBlocked(0,0,4,0,[housing],{},{observation:true}));
  assert(segmentBlocked(0,0,4,0,[housing,wall],{},{observation:true}));
  assert(segmentBlocked(0,0,4,0,[housing],{}));
});

test('parallel, zero-length, reversed and corner-grazing segments are stable',()=>{
  assert(!segmentBlocked(0,-6,0,6,[wall],{}));
  assert(segmentBlocked(2.5,0,2.5,0,[wall],{}));
  assert(segmentBlocked(4,0,0,0,[wall],{}));
  assert(segmentBlocked(1,4,2,5,[wall],{}));
});

test('disabled geometry is ignored and malformed coordinates fail closed',()=>{
  assert(!pointBlocked(2.5,0,[{...wall,enabled:false}],{}));
  assert(!segmentBlocked(0,0,4,0,[{...wall,disabled:true}],{}));
  assert(pointBlocked(NaN,0,[],{}));
  assert(segmentBlocked(NaN,0,1,1,[],{}));
  const p={x:0,z:0};
  moveWithCollisions(p,Infinity,0,[],{});
  assert.equal(p.x,0);
});

test('low furniture can leave an observation line clear while still blocking walking',()=>{
  const table={minX:-1,maxX:1,minZ:2,maxZ:3,minY:0,maxY:.9,observerLOS:false};
  assert.equal(segmentBlocked(0,0,0,5,[table],{},{observation:true}),false);
  const p={x:0,z:0};
  moveWithCollisions(p,0,5,[table],{});
  assert(p.z<1.77,'ignoring a table for eye-level sight must not remove its floor collision');
});

test('a delayed frame cannot skip a closed gate that fine movement also stops at',()=>{
  const coarse={x:0,z:0},fine={x:0,z:0};
  moveWithCollisions(coarse,0,5,[door],{});
  for(let i=0;i<100;i++)moveWithCollisions(fine,0,.05,[door],{});
  assert(coarse.z<door.minZ-.23&&fine.z<door.minZ-.23);
  assert(Math.abs(coarse.z-fine.z)<.12,'both rates stop within one bounded physical substep');
});

test('reopening one gate never clears a later locked gate on the same route',()=>{
  const later={...door,id:'exit_gate',minZ:5,maxZ:5.2};
  const p={x:0,z:0};
  moveWithCollisions(p,0,8,[door,later],{hatch_lab:true});
  assert(p.z>2.2&&p.z<4.77);
  moveWithCollisions(p,0,8-p.z,[door,later],{hatch_lab:true,exit_gate:true});
  assert(Math.abs(p.z-8)<1e-7);
  moveWithCollisions(p,0,-8,[door,later],{hatch_lab:true,exit_gate:true});
  assert(Math.abs(p.z)<1e-7,'the unlocked return route remains traversable');
});
